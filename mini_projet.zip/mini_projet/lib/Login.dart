
import 'package:mini_projet/accountchoice.dart';

import 'dossier.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Login extends StatelessWidget {
  Login({super.key});
@override
Widget build(BuildContext context) {

  return SafeArea(
    child: Scaffold(

      body: SingleChildScrollView(
        child: Center(
          // Center is a layout widget. It takes a single child and positions it
          // in the middle of the parent.
            child: Column(

                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[

                  Container(
                      height: 340.0,

                      child: Image.asset('assets/images/logo2.png')),


                  Padding(
                    padding: const EdgeInsets.only(top:15.0,left: 30.0,right: 30.0,bottom: 15.0),
                    child: TextField(

                      decoration: InputDecoration(
                        fillColor: Colors.white,
                        labelText: "Username",
                        prefixIcon: const Icon(Icons.perm_identity),

                        border: OutlineInputBorder(

                          borderSide: const BorderSide(

                          ),
                          borderRadius: BorderRadius.circular(35.0),
                        ),
                      ),

                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 30.0,right: 30.0),
                    child: TextField(

                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.lock),
                        fillColor: Colors.black,
                        labelText: "Password",
                        border: OutlineInputBorder(

                          borderSide: const BorderSide(

                          ),
                          borderRadius: BorderRadius.circular(35.0),
                        ),
                      ),

                    ),
                  ),
                  const SizedBox(
                    height: 25.0,
                  ),
                  Container(
                    //  color: Colors.green.shade400,
                    width: 180.0,
                    decoration: BoxDecoration(
                      color:Color.fromRGBO(41, 145, 178, 20),
                      borderRadius: BorderRadius.circular(35),
                    ),
                    child:  TextButton(
                        style: ButtonStyle(
                          foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                          overlayColor: MaterialStateProperty.resolveWith<Color?>(
                                (Set<MaterialState> states) {
                              if (states.contains(MaterialState.hovered))
                                return Colors.blue.withOpacity(0.04);
                              if (states.contains(MaterialState.focused) ||
                                  states.contains(MaterialState.pressed))
                                return Colors.blue.withOpacity(0.12);
                              return null; // Defer to the widget's default.
                            },
                          ),
                        ),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const AccountChoice()),
                          );
                        },
                        child: const Text('se connecter')
                    ),

                  ),
                  const SizedBox(height: 15.0,),
                  Padding(
                    padding:const EdgeInsets.only(left: 0.0),
                    child: TextButton(

                        onPressed: () { },
                        child: const Text("Besoin d'aide ?")

                    ),




                  )  ,


                ])
        ),
      ),





    ),


  );

}
}
