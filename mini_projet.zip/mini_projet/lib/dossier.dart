

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Dossier extends StatelessWidget {
  const Dossier({super.key});
  @override
  Widget build(BuildContext context) {

    return SafeArea(

      child: Scaffold(
        appBar: AppBar(title: Text('title')),
        body: SingleChildScrollView(
          child: Center(
            // Center is a layout widget. It takes a single child and positions it
            // in the middle of the parent.
              child: Column(

                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[


                  ])
          ),
        ),
        bottomNavigationBar: Builder(builder: (BuildContext context) {
          return BottomAppBar(
            color: Colors.orange,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                IconButton(icon: Icon(Icons.menu), onPressed: () {
                  Scaffold.of(context).openDrawer();;
                }),
                IconButton(icon: Icon(Icons.message), onPressed: () {}),
              ],
            ),
          );
        },),



    drawer: Drawer(
    // Add a ListView to the drawer. This ensures the user can scroll
    // through the options in the drawer if there isn't enough vertical
    // space to fit everything.
    child: ListView(
    // Important: Remove any padding from the ListView.
    padding: EdgeInsets.zero,
    children: [
    const DrawerHeader(
    decoration: BoxDecoration(
    color: Colors.blue,
    ),
    child: Text('Drawer Header'),
    ),
    ListTile(
    title: const Text('Item 1'),
    onTap: () {
    // Update the state of the app
    // ...
    // Then close the drawer
    Navigator.pop(context);
    },
    ),
    ListTile(
    title: const Text('Item 2'),
    onTap: () {
    // Update the state of the app
    // ...
    // Then close the drawer
    Navigator.pop(context);
    },
    ),
    ],
    ),
      ),


      ),);

  }
}
