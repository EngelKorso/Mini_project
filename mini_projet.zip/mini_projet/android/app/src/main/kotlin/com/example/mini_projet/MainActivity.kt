package com.example.mini_projet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
